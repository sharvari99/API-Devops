package com.springrest.CourseDetails.Entity;

public class Courses {
	private int CourseId;
	private String Name;
	private String Description;
	public Courses(int courseId, String name, String description) {
		super();
		CourseId = courseId;
		Name = name;
		Description = description;
	}
	
	
	public Courses() {
		super();
		
	}


	public int getCourseId() {
		return CourseId;
	}
	public void setCourseId(int courseId) {
		CourseId = courseId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	@Override
	public String toString() {
		return "Courses [CourseId=" + CourseId + ", Name=" + Name + ", Description=" + Description + "]";
	}
	
	

}
