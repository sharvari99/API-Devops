package com.springrest.CourseDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
