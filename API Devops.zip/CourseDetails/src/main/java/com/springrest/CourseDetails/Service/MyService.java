package com.springrest.CourseDetails.Service;

import java.util.List;

import com.springrest.CourseDetails.Entity.Courses;

public interface MyService {

	public List<Courses> getCourses();
		
	public Courses getCourses(long courseid) ;
	
	public Courses addCourses(Courses courses);

	public List<Courses> deleteCourse(int courseid);

	public List<Courses> updateCourses(Courses clientCourses);

	
//	public List<Courses> updateCoursessss(Courses courses);

	
}
