package com.springrest.CourseDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseDetailsApplication {
      public static void main(String[] args) {
		SpringApplication.run(CourseDetailsApplication.class, args);
	}

}
