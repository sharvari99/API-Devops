package com.springrest.CourseDetails.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.springrest.CourseDetails.Entity.Courses;

@Service

public class MyServiceImpl implements MyService {

	List<Courses> list;

	public MyServiceImpl() {
		list = new ArrayList<>();
		list.add(new Courses(345, "Core java", "This course contains basics of java"));
		list.add(new Courses(4567, "Advanced java", "This course contains advance of java"));
		list.add(new Courses(789, "Springboot course", "Creating rest API using springboot"));
	}

	@Override
	public List<Courses> getCourses() {
		return list;
	}

	@Override
	public Courses getCourses(long courseid) {

		Courses c = null;
		for (Courses courses : list) {
			if (courses.getCourseId() == courseid) {
				c = courses;
				break;
			}
		}

		return c;

	}

	@Override
	public Courses addCourses(Courses courses) {
		list.add(courses);
		return courses;
	}

	@Override
	public List<Courses> deleteCourse(int courseid) {
		Courses deletecourse = null;
		for (Courses courses : list) {
			if (courses.getCourseId() == courseid) {
				deletecourse = courses;
			}
		}
		list.remove(deletecourse);
		return list;
	}

	@Override
	public List<Courses> updateCourses( Courses clientCourses) {

		for (Courses courses : list) {
			if (courses.getCourseId() == clientCourses.getCourseId()) {
				courses.setName(clientCourses.getName());
			    courses.setDescription(clientCourses.getDescription());
			}
		}
		return list;
	}

}
