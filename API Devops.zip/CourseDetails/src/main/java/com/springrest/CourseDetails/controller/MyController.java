package com.springrest.CourseDetails.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.springrest.CourseDetails.Entity.Courses;
import com.springrest.CourseDetails.Service.MyService;

@RestController
@CrossOrigin("http://localhost:8080")
public class MyController {
	@Autowired
	private MyService myservice;
	
    @GetMapping("home")
	public String getHomepage()
	{
		return "This is home page";
	}
	
	  
    @GetMapping("Courses")
	public List<Courses> getCourses()
	{
	return this.myservice.getCourses();
    }
		
	@GetMapping("Courses/{courseid}")
	public Courses getCourses(@PathVariable String courseid) 
	{
	return (Courses) this.myservice.getCourses(Long.parseLong(courseid));	
    }
	
	@PostMapping("Courses")
	public Courses addCourses(@RequestBody Courses courses) {
		return this.myservice.addCourses(courses);
		
	}
	
	@PutMapping("Courses")
	public List<Courses> updateCourses(@RequestBody Courses courses) {
	return this.myservice.updateCourses(courses);
	
	}

	@DeleteMapping("Courses/{courseid}")
	public List<Courses> deleteCourse(@PathVariable("courseid") int courseid) {
	return this.myservice.deleteCourse(courseid);	
	}

	
	
	}




